"use client";

import type { ReactNode } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/app/components/AuthContext";
import { homeForRole, loginUrlFor } from "@/app/lib/auth-redirect";
import Icon from "../../components/Icon";

export default function AdminLayout({ children }: { children: ReactNode }) {
  const { user, isLoading, logout } = useAuth();
  const router = useRouter();
  // Until the account is confirmed as admin, the admin area stays hidden behind a notice.
  // The page itself still renders (hidden), so Next.js can validate the segment.
  const allowed = !isLoading && user?.role === "admin";
  let gate: ReactNode = null;

  if (isLoading) {
    gate = (
      <div className="min-h-screen flex items-center justify-center bg-background text-foreground">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-2 border-foreground border-t-transparent rounded-full animate-spin keep-motion" />
          <p className="text-xs text-muted-foreground font-medium">Memverifikasi otoritas Super Admin...</p>
        </div>
      </div>
    );
  }

  // Route guard: Access restricted strictly to Admin role
  else if (!allowed) {
    gate = (
      <div className="min-h-screen flex items-center justify-center p-4 bg-background">
        <div className="card-base max-w-md w-full p-8 text-center border-2 border-foreground relative overflow-hidden">
          <div className="w-16 h-16 mx-auto mb-4 bg-foreground text-primary flex items-center justify-center">
            <Icon name="lock" size={32} />
          </div>
          <h1 className="page-header-title mb-2">Akses Khusus Super Admin</h1>
          <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
            Halaman ini berada di tingkat tertinggi platform dan hanya dapat diakses oleh Administrator resmi untuk mengelola Campaign Master dan kurasi event organizer.
          </p>
          <div className="flex flex-col gap-2.5">
            <Link
              href={user && user.role !== "guest" ? homeForRole(user.role) : loginUrlFor("/dashboard/admin")}
              className="btn btn-primary w-full text-xs py-2.5 shadow-md"
              id="admin-login-redirect-btn"
            >
              {user && user.role !== "guest" ? "Kembali ke Dashboard Saya" : "Masuk sebagai Admin"}
            </Link>
            <button
              type="button"
              onClick={() => router.push("/")}
              className="btn btn-ghost w-full text-xs py-2 text-muted-foreground"
            >
              Kembali ke Beranda
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
    {gate}
    <div className="min-h-screen bg-background text-foreground flex flex-col" style={allowed ? undefined : { display: "none" }} aria-hidden={!allowed || undefined}>
      {/* Top Admin Bar */}
      <header className="sticky top-0 z-40 border-b-2 border-foreground bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/dashboard/admin" className="flex items-center gap-2 group">
              <div className="w-9 h-9 bg-foreground text-primary flex items-center justify-center">
                <span className="text-lg"><Icon name="shield" size={20} /></span>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="wordmark text-base">Boothify</span>
                  <span className="badge bg-info/15 text-info">
                    Super admin
                  </span>
                </div>
                <p className="text-[10px] text-muted-foreground hidden sm:block">
                  Pusat Kurasi Campaign &amp; Penyelarasan Event Organizer
                </p>
              </div>
            </Link>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 border border-border">
              <span className="text-xs"><Icon name="shield" size={16} /></span>
              <span className="text-xs text-muted font-medium">Tingkat Hak Akses Tertinggi</span>
            </div>

            <Link
              href="/events"
              className="btn btn-secondary btn-sm text-xs py-1.5 px-3 hidden sm:inline-flex"
            >
              Lihat Katalog Publik
            </Link>

            <button
              type="button"
              onClick={logout}
              className="btn btn-ghost btn-sm text-xs text-muted-foreground hover:text-error"
              id="admin-logout-btn"
            >
              Keluar
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6">
        {children}
      </main>
    </div>
    </>
  );
}
